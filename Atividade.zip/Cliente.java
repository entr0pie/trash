package sgi;

public class Cliente {
	private String CPF;
	public String nome;
	public String email;
	public Conta conta;
	
	public Cliente(String CPF, String nome, String email, Conta conta) {
		this.CPF = CPF;
		this.nome = nome;
		this.email = email;
		this.conta = conta;
	}
	
	public String checarCPF() {
		return this.CPF;
	}
}
