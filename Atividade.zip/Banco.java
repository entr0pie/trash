package sgi;

import java.util.ArrayList;

public class Banco {
	private int id;
	public String nome_do_banco;
	public ArrayList<Cliente> clientes = new ArrayList<Cliente>();
	
	public Banco(int id, String nome_do_banco) {
		this.id = id;
		this.nome_do_banco = nome_do_banco;
	}
}
