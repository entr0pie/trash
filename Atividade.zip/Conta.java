package sgi;

public class Conta {
	public String numero;
	public String tipo;
	private double saldo = 0;
	
	public Conta(String numero, String tipo) {
		this.numero = numero;
		this.tipo = tipo;
	}
	
	public boolean sacar(double valor) {
		if (valor > this.saldo) {return false;}
		this.saldo -= valor;
		return true;
	}
	
	public boolean depositar(double valor) {
		this.saldo += valor;
		return true;
	}
	
	public double checarSaldo() {
		return this.saldo;
	}
	
}
