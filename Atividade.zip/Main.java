package sgi;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Main {

	public static void main(String[] args) {
		Banco meu_banco = new Banco(1, "Santo André");
		Conta primeira_conta = new Conta("123", "CC");
		Cliente primeiro_cliente = new Cliente("123456789", "Pedro de Lara", "plara@gmail.com", primeira_conta);
		meu_banco.clientes.add(primeiro_cliente);
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		System.out.println("===================JSON====================");
		System.out.println("Banco:\n" + gson.toJson(meu_banco));
		System.out.println("-------------------------------------------");
		System.out.println("Conta:\n" + gson.toJson(primeira_conta));
		System.out.println("-------------------------------------------");
		System.out.println("Cliente:\n" + gson.toJson(primeiro_cliente));
		System.out.println("===========================================\n");

		String json_segundo_banco = ""
				+ "{\"id\":2,\"nome_do_banco\":\"Nubanco\","
				+ "\"clientes\":[{\"CPF\":\"987654321\",\"nome\":\"Lara de Pedro\","
				+ "\"email\":\"ldpedro@gmail.com\",\"conta\":{\"numero\":\"8723\",\"tipo\":\"CP\",\"saldo\":1000.0}}]}";
		
		Banco segundo_banco = gson.fromJson(json_segundo_banco, Banco.class);
		
		System.out.println("=============JSON_SERIALIZADO==============");
		System.out.println("Banco: " + segundo_banco.nome_do_banco);
		System.out.println("Clientes:");
		
		for (int i = 0; i < segundo_banco.clientes.size(); i++) {
			System.out.println(" > Cliente " + i + ":");
			System.out.println("  > CPF: " + segundo_banco.clientes.get(i).checarCPF());			
			System.out.println("  > Nome: " + segundo_banco.clientes.get(i).nome);
			System.out.println("  > Email: " + segundo_banco.clientes.get(i).email);
			System.out.println("  > Conta: ");
			System.out.println("   > Número: " + segundo_banco.clientes.get(i).conta.numero);
			System.out.println("   > Tipo: " + segundo_banco.clientes.get(i).conta.tipo);
			System.out.println("   > Saldo: " + segundo_banco.clientes.get(i).conta.checarSaldo());
		}
		
		System.out.println("===========================================\n");
		
	}

}
