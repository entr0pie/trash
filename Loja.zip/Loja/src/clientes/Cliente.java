package clientes;

import java.io.FileWriter;

public class Cliente {
	private String cpf;
	public String nome;
	public String email;
	public String telefone;
	
	public Cliente(String cpf, String nome, String email, String telefone) {
		if (!Handler.usuarioExiste(cpf)) {System.exit(1);}
		
		this.cpf = cpf;
		this.nome = nome;
		this.email = email;
		this.telefone = telefone;
		
	}
	
	public String getCPF() {return this.cpf;}
		
	public boolean salvar() throws Exception {
		
		try {
	      FileWriter myWriter = new FileWriter("C:\\_src\\Loja\\src\\clientes\\clientes.csv", true);
	      myWriter.write(String.format("\n%s,%s,%s,%s", this.cpf, this.nome, this.email, this.telefone));
	      myWriter.close();
	    } 
		
		catch (Exception e) {
	      e.printStackTrace();
	    }
				
		return true;
	}
	

}
