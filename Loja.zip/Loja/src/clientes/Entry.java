package clientes;

import java.io.FileNotFoundException;

public class Entry {
	public static void main(String[] args) {
//		Cliente cliente = new Cliente("1238", "Pedro de Lara", "p_lara@mail.com", "+5514213512312");
//		try {
//			cliente.salvar();
//		} 
//		
//		catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		System.out.println("fodeu");
//		
//		try {
//			System.out.println("começo");
//			Cliente cliente = Handler.buscaUsuario("123");
//			System.out.println("fim");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		
		try {
			System.out.println(Handler.buscaTodos());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
}
