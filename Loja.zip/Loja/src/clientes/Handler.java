package clientes;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Handler {
	private static String leArquivoCliente() throws FileNotFoundException {
		String content = "";
			
        try {
	        File myObj = new File("C:\\_src\\Loja\\src\\clientes\\clientes.csv");
	        Scanner myReader = new Scanner(myObj);
	        while (myReader.hasNextLine()) {
	          content += myReader.nextLine() + "\n";
	        }
	        myReader.close();
	        
	    } catch (FileNotFoundException e) {throw e;}
        
        return content;
	
	}
	
	
	public static boolean usuarioExiste(String cpf) {
		String[] lines = null;
		try {
			lines = Handler.leArquivoCliente().split("\n");
		} catch (FileNotFoundException e) {System.exit(1);}
	    
	    String[] data = null;
	
	    for (int i = 1; i < lines.length; i++) {
	    	if (lines[i].contains(cpf)) {
	    		return true;
	    	}
	    }
	    	    
	    return false;
	}
	
	public static Cliente buscaUsuario(String cpf) throws Exception {
	    String[] lines = Handler.leArquivoCliente().split("\n");
	    
	    String[] data = null;
	    
	    for (int i = 1; i < lines.length; i++) {
	    	if (lines[i].contains(cpf)) {
	    		
	    		data = lines[i].split(","); 
	    		break;
	    	}
	    }
	    	    
	    if (data == null) {throw new Exception("CPF não encontrado.");}
	    
	    return new Cliente(data[0], data[1], data[2], data[3]);
	}
	
	public static ArrayList<Cliente> buscaTodos() throws FileNotFoundException {
	    String lines[] = null;
		try {lines = Handler.leArquivoCliente().split("\n");}
	    catch (FileNotFoundException e) {throw e;}
		
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		
		for (int i = 1; i < lines.length; i++) {
			String[] data = lines[i].split(",");
			clientes.add(new Cliente(data[0], data[1], data[2], data[3]));
		}
		
		return clientes;
	}
	
}
