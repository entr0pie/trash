#!/bin/node

const PATH = "C:\\Users\\Aluno\\Desktop\\lojafoda\\"

const express = require('express');
const APP = express();
const PORT = 3000;

const bodyParser = require('body-parser');
const URLPARSER = bodyParser.urlencoded({ extended: false });
APP.use(URLPARSER);

const fs = require('fs');

APP.use("/index/style.css", express.static("./templates/index/style.css"));
APP.use("/searchClient/style.css", express.static("./templates/searchClient/style.css"));
const Cliente = require('./src/cliente');

APP.get("/", (req, res) => {
    const lines = Cliente.buscaTodos();
    if (lines == undefined) {res.send("Oh no! The estagiario drop the database!!!1");}
    var table_content = "";
    
    for (var i = 1; i < lines.length; i++) {
        table_content += "<tr>\n";
        const columns = lines[i].split(',');
        for (var j = 0; j < columns.length; j++) {
            if (columns[j].trim() == "") {break;}
            table_content += `<td>${columns[j].trim()}</td>\n`;
        }
        table_content += "</tr>\n";
    }

    var template = fs.readFileSync("templates/index/index.html", {encoding: "utf-8", flag: 'r'});
    template = template.replace("<tr><td>VALUES</td></tr>", table_content);
    res.send(template);
});

APP.post("/createAccount", URLPARSER, (req, res) => {
    const cliente = new Cliente(req.body.cpf, req.body.nome, req.body.email, req.body.telefone);
    cliente.salvar();
    res.send("ok.")
});

APP.get("/searchAccount", (req, res) => {
    if (req.query.cpf == undefined){res.statusCode = 404; res.redirect("https://bongo.cat"); }
    const line = Cliente.buscaUsuario(req.query.cpf);  
    if (line == undefined) {res.send("Digitou certo, seu burro?");}
    var table_content = "<tr>\n";

    for (var i = 0; i < line.length; i++) {
        table_content += `<td>${line[i]}</td>`
    }
    
    table_content += "</tr>";
    var template = fs.readFileSync("templates/searchClient/search.html", {encoding: "utf-8", flag: 'r'});
    template = template.replace("<tr><td>VALUES</td></tr>", table_content);
    template = template.replace("$PESQUISA", req.query.cpf);

    res.send(template);
});

APP.listen(PORT, () => {console.log(`Server running at ${PORT}`)});