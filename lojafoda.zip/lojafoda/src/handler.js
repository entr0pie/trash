const fs = require('fs');

function readEntries(path) {
    try {return fs.readFileSync(path, {encoding: "utf-8", flag: 'r'}).split('\n');}
    catch (ENOENT) {return false;}
}

function findAll() {

}


module.exports = {findAll, readEntries};

readEntries("aaaaaaaaaaaa")