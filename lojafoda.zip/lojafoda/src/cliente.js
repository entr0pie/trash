const fs = require('fs');

const PATH = "clients.csv";

class Cliente {
    
    #cpf;

    constructor(cpf, nome, email, telefone) {
        this.#cpf = cpf;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
    }

    salvar() {
        const _ = fs.readFileSync(PATH, {encoding: "utf-8", flag: 'r'});
        fs.appendFileSync(PATH, `${this.#cpf},${this.nome},${this.email},${this.telefone}\n`);
    }

    static buscaUsuario(cpf) {
        var content;
        try {content = fs.readFileSync(PATH, {encoding: "utf-8", flag: 'r'}).split('\n');}
        catch (ENOENT) {return undefined;}

        for (var i = 0; i < content.length; i++) {
            if (content[i].includes(cpf)) {
                return content[i].split(',');
            }
        }

        

        
    }

    static buscaTodos(path="/clients.csv") {        
        try {return fs.readFileSync(PATH, {encoding: "utf-8", flag: 'r'}).split('\n');}
        catch (ENOENT) {return undefined;}
    }

}

module.exports = Cliente;